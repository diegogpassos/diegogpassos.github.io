#!/usr/bin/python

import sys
import audioInput
import time
import math

def readByte(firstSample, SymbolDuration, threshold, freqSNR1, freqSNR2):
    
    receivedBits = []

    if freqSNR1 > threshold:
        nextBit = 0
    else:
        nextBit = 1

    i = time.time()
    maxTime = i + SymbolDuration * 8
    lastBitStart = firstSample

    while i < maxTime:
        freqPwr1, freqPwr2, avgPwr = ai.searchForTwoFrequencies(freq1, freq2);
        freqSNR1 = freqPwr1 - avgPwr
        freqSNR2 = freqPwr2 - avgPwr

        if (nextBit == 0 and freqSNR1 < threshold) or (nextBit == 1 and freqSNR2 < threshold):
            # Possivel final de um ou mais bits. Verificar duracao.
            interval = i - lastBitStart
            print "Sinal detectado por %f segundos" % interval

            # Calcular numero de bits consecutivos
            nBits = interval / SymbolDuration

            # Deve haver ao menos um bit completo
            if round(nBits) == 0:
                print "Nenhum bit!"
                return ([], -1)

            # Duracao deve ser aproximandamente um multiplo da duracao de um bit
            normalizedDuration = nBits / round(nBits)
            if normalizedDuration > 0.8 and normalizedDuration < 1.2:
                nBits = int(round(nBits))
            else:
                print "Intervalo muito curto!"
                return ([], -2)

            # Novos bits recebidos com sucesso
            print "Recebidos %d bits %d\n" % (nBits, nextBit)
            receivedBits = receivedBits + [nextBit] * nBits

            # Byte ja completo?
            if len(receivedBits) >= 8:
                return (receivedBits, 0)

            # Byte ainda nao esta completo. Deve haver outro bit em transmissao
            if freqSNR1 < threshold and freqSNR2 < threshold:
                print "Byte muito curto!"
                return (0, -3)

            # Armazenar valor do proximo bit e momento de inicio
            nextBit = (nextBit + 1) % 2
            lastBitStart = i

        # Sinal foi perdido?
        if freqSNR1 < threshold and freqSNR2 < threshold:
            print "Byte muito curto!"
            return (0, -3)

        i = time.time()

    # Duracao do pacote todo acabou. Possivel final de um ou mais bits. Verificar duracao.
    interval = i - lastBitStart
    print "Sinal detectado por %f segundos" % interval

    # Calcular numero de bits consecutivos
    nBits = interval / SymbolDuration

    # Deve haver ao menos um bit completo
    if round(nBits) == 0:
        print "Nenhum bit!"
        return ([], -1)

    # Duracao deve ser aproximandamente um multiplo da duracao de um bit
    normalizedDuration = nBits / round(nBits)
    if normalizedDuration > 0.8 and normalizedDuration < 1.2:
        nBits = int(round(nBits))
    else:
        print "Intervalo muito curto!"
        return ([], -2)

    # Novos bits recebidos com sucesso
    print "Recebidos %d bits %d\n" % (nBits, nextBit)
    receivedBits = receivedBits + [nextBit] * nBits

    # Byte ja completo?
    if len(receivedBits) >= 8:
        return (receivedBits, 0)

    # Se chegamos ate aqui, algo errado aconteceu
    print "Tempo maximo excedido!"
    return ([], -4)

def listToInteger(l):

    val = 0
    l.reverse()
    for i in l:
        val = val * 2
        if i == 1:
            val = val + 1
    return val


# Duracao de um simbolo (s)
SymbolDuration = 4.0

# Frequencias associadas a cada bit
freq1 = 330
freq2 = 440

# Limiar de aceitacao de um simbolo
threshold = 10

# Verificacao das opcoes de linha de comando
if len(sys.argv) > 1:
	if len(sys.argv) > 2:
		print 'Uso: ' + sys.argv[0] + ' [DuracaoSimbolo]'
		sys.exit(1)
	else:
		if sys.argv[1] == '-h':
			print 'Uso: ' + sys.argv[0] + ' [DuracaoSimbolo]'
			sys.exit(1)
		else:
			SymbolDuration = float(sys.argv[1])


# Duracao de cada captura de audio. Usamos sempre a duracao de um simbolo dividido por 16.
#SampleTime = SymbolDuration / 32
SampleTime = 0.100

# Inicializar dispositivo de captura de audio
ai = audioInput.audioInput(SampleTime)

while True:
	
	# Tirar nova amostra
        lastSample = time.time()
	freqPwr1, freqPwr2, avgPwr = ai.searchForTwoFrequencies(freq1, freq2)
        freqSNR1 = freqPwr1 - avgPwr
        freqSNR2 = freqPwr2 - avgPwr

	if (freqSNR1 >= threshold and freqSNR2 < threshold) or (freqSNR1 < threshold and freqSNR2 >= threshold):
		print 'Possivel mensagem...'
		# Possivel bit. Delegar recepcao do byte
		byte, error  = readByte(lastSample, SymbolDuration, threshold, freqSNR1, freqSNR2)
		# Byte foi completo?
		if error == 0:
			print 'Confirmado byte!'
                        print byte
                        ch = listToInteger(byte)
                        print "Valor decimal do byte: %d\n" % ch
                        print "Caractere ASCII: %c\n" % chr(ch)
		else:
			print 'Falso positivo!'



